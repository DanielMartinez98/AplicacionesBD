package com.example.myapplication;

public class listWhatsapp {
    public String number;
    public String power;
    public boolean check;
    public String classid;
    public listWhatsapp(String number, String power,boolean check,String classid) {
        this.number = number;
        this.power = power;
        this.check = check;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }
}
