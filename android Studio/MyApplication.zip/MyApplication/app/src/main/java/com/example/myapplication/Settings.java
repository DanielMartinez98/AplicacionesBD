package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
    }
    public void MainScreenSettings(View view)
    {
        Intent actividad = new Intent(this, MainScreen.class);
        startActivity(actividad);
    }
    public void ModificarCuentaSettings(View view)
    {
        Intent actividad = new Intent(this, ModificarCuenta.class);
        startActivity(actividad);
    }
    public void LogInSettings(View view)
    {
        Intent actividad = new Intent(this, LogIn.class);
        startActivity(actividad);
    }
    public void AdministracionDeClasesSettings(View view)
    {
        Intent actividad = new Intent(this, AdministracionDeClases.class);
        startActivity(actividad);
    }
}