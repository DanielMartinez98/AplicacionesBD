package com.example.myapplication;

import android.view.View;

public class listaClase {
    public String nombre;
    public String id;
    public listaClase(String nombre,  String id) {
        this.nombre = nombre;
        this.id  = id;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
