package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

public class Singleton {
    /**Creacion de Clase singleton para restringir la creacion de objetos pertenecientes a una clase
     * una clase o el valor de tipo a un unico objeto **/

    private  static Singleton mSingletonInstance;
    private RequestQueue mRequestQueue;
    private static Context mContext;

    /** creamos una instancia SingleTon con el constructor privado para poder utilizarla
     * internamente **/
    private Singleton(Context context)
    {
        mContext = context;
        mRequestQueue = getRequestQueue();

    }
    /** Manejo de sincornizacion
     * Cada vez que un thread intenta de acceder a un bloque sincronizado, le pregunta a ese Objeto
     * si no hay algun otro thread ejecutandose algun otro bloque, de otra forma ocurre lo que
     * se llama un lock para ese Objeto.
     * En pocas palabras, pregunta  si no hay otro thread ejecutandose , si lo hay se suspende y ejecuta
     * el thread actual hasta que se libere la ejeucion, menejo de hilos **/
    public static synchronized Singleton getInstance(Context context)
    {
        if(mSingletonInstance == null)
        {
            mSingletonInstance = new Singleton(context);
        }
        return  mSingletonInstance;
    }

    public RequestQueue getRequestQueue() {
        if(mRequestQueue == null)
        {
            mRequestQueue = Volley.newRequestQueue((mContext.getApplicationContext()));
        }
        return mRequestQueue;
    }
    /** Tipo generico y lo agregamos el queue de solicitudes,
     *  en el Constructor Creamos un Objeto ImageLoader**/
    public <T> void addRequestQueue(Request<T> req ,String tag)
    {
        req.setTag(tag);
        getRequestQueue().add(req);
    }

}

