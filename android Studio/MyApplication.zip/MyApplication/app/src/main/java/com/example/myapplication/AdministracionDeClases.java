package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class AdministracionDeClases extends AppCompatActivity {
    List<listaClase> elements;
    DataBaseHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administracion_de_clases);
        DB =new DataBaseHelper(this);
        initLista();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        initLista();
    }

    public void SettingsAdministracionDeClases(View view)
    {
        //Intent actividad = new Intent(this, Settings.class);
       //startActivity(actividad);
        finish();
    }
    public void AgregarClasePorCodigoAdministacionDeClases(View view)
    {
        Intent actividad = new Intent(this, AgregarClasePorCodigo.class);
        startActivity(actividad);
    }
    public void AgregarClaseAdministracionDeClases(View view)
    {
        Intent actividad = new Intent(this, AgregarClase.class);
        startActivity(actividad);
    }
    public void initLista()
    {
        elements = new ArrayList<>();
        Cursor cursor = DB.retrieveDataClases();
        while(cursor.moveToNext())
        {
            elements.add(new listaClase(cursor.getString(1),cursor.getString(0)));
        }
        listAdapterClase listclase = new listAdapterClase(elements,this);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewClase);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listclase);
    }
}