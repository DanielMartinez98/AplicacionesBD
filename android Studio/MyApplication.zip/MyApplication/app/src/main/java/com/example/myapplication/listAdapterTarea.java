package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class listAdapterTarea extends RecyclerView.Adapter<listAdapterTarea.ViewHolder>
{
    private List<listaTarea> mData;
    private LayoutInflater mInflater;
    private Context context;
    public  View view;

    public listAdapterTarea(List<listaTarea> mData, Context context) {
        this.mData = mData;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public int getItemCount(){return mData.size();}

    @Override
    public listAdapterTarea.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = mInflater.inflate(R.layout.listatarea,null);
        return new listAdapterTarea.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final listAdapterTarea.ViewHolder holder,final int position)
    {
        holder.bindData(mData.get(position));
        listaTarea val1 = mData.get(position);
        String val = val1.id;
        holder.itemView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view1)
            {
                Intent actividad = new Intent(context,ModificarTarea.class);
                actividad.putExtra("StringVariableName",val);
                context.startActivity(actividad);


            }
        });
    }

    public  void setItems(List<listaTarea> items){mData=items;}

    public class ViewHolder extends  RecyclerView.ViewHolder
    {

        TextView nombre,clase,fecha;
        ViewHolder(View itemView)
        {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombreTarea);
            clase = itemView.findViewById(R.id.ClasesTarea);
            fecha = itemView.findViewById(R.id.TareasDias);
        }
        void bindData(final listaTarea item)
        {
            nombre.setText(item.getNombre());
            clase.setText(item.getClase());
            fecha.setText(item.getDate());
            itemView.setBackgroundColor((item.getColor()));
        }
    }
}
