package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Debug;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.nio.Buffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MainScreen extends AppCompatActivity {

    public  View view;
    List<listaTarea> elements;
    DataBaseHelper DB;
    public int count,completed;
    public static final String misPreferencias = "MisPref";
    public static final String ID = "llaveId";
    public TextView percentage;
    public ProgressBar progressBar;
    public Spinner dias;
    SharedPreferences shrd;
    private String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
        percentage = (TextView)findViewById(R.id.percentageString);
        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        dias =(Spinner)findViewById(R.id.diasSpinner);
        DB =new DataBaseHelper(this);
        DB.onUpgrade(this.DB.getWritableDatabase(),1,1);
        DB.onCreate(this.DB.getWritableDatabase());
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        if(shrd.contains(ID))
        {
            id = (shrd.getString(ID,""));
        }
        RefreshSQLiteTarea();
        RefreshSQLiteClases();
        RefreshShrd();
    }
    @Override
    protected void onResume() {
        super.onResume();
        RefreshSQLiteTarea();
        RefreshSQLiteClases();
        RefreshShrd();
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        initLista();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        initLista();
    }

    public void AgregarTareaMainScreen(View view)
    {
        Intent actividad = new Intent(this,AgregarTarea.class);
        startActivity(actividad);
    }
    public void CalendarioMainScreen(View view)
    {
        Intent actividad = new Intent(this,Calendario.class);
        startActivity(actividad);
    }
    public void SettingsMainScreen(View view)
    {
        Intent actividad = new Intent(this,Settings.class);
        startActivity(actividad);
    }
    public void initLista()
    {
        Cursor cursor = DB.retrieveDataTareas();
        elements = new ArrayList<>();
        while(cursor.moveToNext())
        {
            String dateStr = cursor.getString(3);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date;
            String dat ="0";
            String color;
            try {
                Log.d("",dateStr);
                date = sdf.parse(dateStr);
                Log.d("",date+"");
                long diff = date.getTime() - Calendar.getInstance().getTime().getTime();
                dat = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)+"";
                Log.d("",dat);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if(Integer.parseInt(dat)<3)
            {
                color = "#FF0000";
            }
            else if(Integer.parseInt(dat)<5)
            {
                color = "#FFFFE0";
            }
            else
            {
                color = "#FFFFFF";
            }
            String val =(dias.getSelectedItem().toString());
            if(Integer.parseInt(dat)>-50 & Integer.parseInt(dat) < Integer.parseInt(val))
            {
                count++;
                if(cursor.getString(2).equals("1")) {
                    color = "#0F9D58";
                    completed++;
                }
                elements.add(new listaTarea( cursor.getString(6),dat,cursor.getString(5),cursor.getString(0), Color.parseColor(color)));
            }
        }
        Log.d(completed+"",count+"");
        int amount =(Math.round(((completed)/(1f*count))*100));
        String pholder=  amount+"% Completed";
        percentage.setText(pholder);
        progressBar.setProgress(amount);
        listAdapterTarea listTarea = new listAdapterTarea(elements,this);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewtarea);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listTarea);
    }
    public void RefreshSQLiteTarea()
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",id);
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        MyJsonArrayRequest myJsonArrayRequest = new MyJsonArrayRequest(Request.Method.POST,"http://34.151.197.253:5000/selectTareas",obj,response ->
        {
          for(int i=0;i<response.length();i++)
          {
              String arr[]= new String[7];
              JSONObject jsonObject = new JSONObject();
              try {
                  jsonObject = response.getJSONObject(i);
                  arr[0] = jsonObject.getString("Clases.nombre");
                  arr[1] = jsonObject.getString("descripcion");
                  arr[2] = jsonObject.getString("estatus");
                  arr[3] = jsonObject.getString("fecha_entrega");
                  arr[4] = jsonObject.getString("id_clase");
                  arr[5] = jsonObject.getString("id_tarea");
                  arr[6] = jsonObject.getString("nombre");
                  DB.insertDataTareas(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
                  initLista();
              } catch (JSONException e) {
                  e.printStackTrace();
              }

          }
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonArrayRequest,REQUEST_TAG);
    }
    public void RefreshSQLiteClases()
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",id);
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        MyJsonArrayRequest myJsonArrayRequest = new MyJsonArrayRequest(Request.Method.POST,"http://34.151.197.253:5000/selectClases",obj,response ->
        {
            for(int i=0;i<response.length();i++)
            {
                String arr[]= new String[3];
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject = response.getJSONObject(i);
                    arr[0] = jsonObject.getString("administrador");
                    arr[1] = jsonObject.getString("id_clase");
                    arr[2] = jsonObject.getString("nombre");
                    DB.insertDataClases(arr[0],arr[1],arr[2]);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonArrayRequest,REQUEST_TAG);
    }
    public void RefreshShrd()
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",id);
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        MyJsonArrayRequest myJsonArrayRequest = new MyJsonArrayRequest(Request.Method.POST,"http://34.151.197.253:5000/selectInfoUsuario",obj,response ->
        {
            SharedPreferences.Editor editor = shrd.edit();
            for(int i=0;i<response.length();i++)
            {
                String arr[]= new String[7];
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject = response.getJSONObject(i);
                    editor.putString("nombre", jsonObject.getString("nombre")+" "+jsonObject.getString("apellido_paterno")+" "+jsonObject.getString("apellido_materno"));
                    editor.putString("telefono",jsonObject.getString("telefono"));
                    editor.putString("whatsapp",jsonObject.getString("whatsapp"));
                    DB.insertDataTareas(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
                    initLista();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonArrayRequest,REQUEST_TAG);
    }
}
