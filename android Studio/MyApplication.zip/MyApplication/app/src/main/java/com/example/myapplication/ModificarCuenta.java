package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.ToggleButton;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class ModificarCuenta extends AppCompatActivity {
    SharedPreferences shrd;
    public static final String misPreferencias = "MisPref";
    public static final String Mail = "llavemail";
    public static final String Password = "llavepassword";
    public static final String ID = "llaveId";
    public EditText n,m,t;
    public boolean check;
    public Switch toggleButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_cuenta);
        n =(EditText)findViewById(R.id.name);
        m=(EditText)findViewById(R.id.mail);
        t=(EditText)findViewById(R.id.telefono);
        toggleButton=(Switch) findViewById(R.id.switch1);
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        n.setText(shrd.getString("nombre",""));
        m.setText(shrd.getString(Mail,""));
        t.setText(shrd.getString("telefono",""));
        if(shrd.getString("whatsapp","").equals("1"))
        {
            check=true;
            toggleButton.setChecked(true);
        }
    }
    public void SettingsModificarCuenta(View view)
    {
        finish();
    }
    public void CambiarPasswordModificarCuenta(View view)
    {
        Intent actividad = new Intent(this, CambiarPassword.class);
        startActivity(actividad);
    }
    public void GuardarCambiosModificarCuenta(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",shrd.contains(ID));
            obj.put("nombre",n.getText().toString());
            obj.put("apellidoPaterno","");
            obj.put("apellidoMaterno","");
            obj.put(Mail,m.getText().toString());
            obj.put("telefono",t.getText().toString());
            obj.put(Password,shrd.contains(Password));
            if (check)
            {
                obj.put("whatsapp","1");
            }else{
                obj.put("whatsapp","0");
            }

        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarCuenta",obj, response ->
        {
            SharedPreferences.Editor editor = shrd.edit();
            editor.putString("nombre",n.getText().toString());
            editor.putString("apellidoPaterno","");
            editor.putString("apellidoMaterno","");
            editor.putString(Mail,m.getText().toString());
            editor.putString("telefono",t.getText().toString());
            if (check)
            {
                editor.putString("whatsapp","1");
            }else{
                editor.putString("whatsapp","0");
            }
            finish();
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
    }

}