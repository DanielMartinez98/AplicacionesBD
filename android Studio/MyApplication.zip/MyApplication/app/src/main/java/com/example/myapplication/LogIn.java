package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class LogIn extends AppCompatActivity {

    public EditText mail,password;
    SharedPreferences shrd;
    private static Singleton singleton;
    public static final String misPreferencias = "MisPref";
    public static final String Mail = "llavemail";
    public static final String Password = "llavepassword";
    public static final String ID = "llaveId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        mail=(EditText)findViewById(R.id.editTextTextEmailAddress);
        password=(EditText)findViewById(R.id.editTextTextPassword);
        singleton = Singleton.getInstance(getApplicationContext());
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        if(shrd.contains(Mail))
        {
            mail.setText(shrd.getString(Mail,""));
        }
        if(shrd.contains(Password))
        {
            password.setText(shrd.getString(Password,""));
        }
    }
    public void LogInLogIn(View view)
    {
        String REQUEST_TAG = "objeto.ObjectRequest";
        String n = mail.getText().toString();
        String c = password.getText().toString();
        //Toast.makeText(this, c.toString(), Toast.LENGTH_LONG).show();
        if(n.length()!=0&c.length()!=0)
        {
            JSONObject jsonObject = new JSONObject();
            try{
                jsonObject.put("emailEstudiante",n.toString());
                jsonObject.put("passwordEstudiante",c.toString());
            }catch (Throwable e){
                //jsonObject = new JSONObject();
                Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
            }
            SharedPreferences.Editor editor = shrd.edit();
            //RequestQueue requestQueue = Volley.newRequestQueue(this);
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/userLogin",jsonObject,response ->
            {

                Toast.makeText(this, "im in!", Toast.LENGTH_LONG).show();
                try {

                    String resp =response.getString("Response");
                    Log.d("",resp);
                    if(!resp.equals("Usuario y/o Contraseña incorrectos"))
                    {
                        editor.putString(ID, resp);
                        editor.putString(Mail, n);
                        editor.putString(Password, c);
                        editor.commit();
                        Intent actividad = new Intent(this,MainScreen.class);
                        startActivity(actividad);
                    }else
                    {
                        Toast.makeText(this, "mail or password are incorrect", Toast.LENGTH_LONG).show();
                    }
                }catch (Throwable e){
                    Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
                }
            },error -> {
                Log.d("",error.toString());
                Toast.makeText(this, error.toString()+"", Toast.LENGTH_LONG).show();
            });
            Log.d("","aa");
            Singleton.getInstance(getApplicationContext()).addRequestQueue(jsonObjectRequest,REQUEST_TAG);
            //requestQueue.add(jsonObjectRequest);
        }else
        {
            Toast.makeText(this, "1 or more spaces is empty", Toast.LENGTH_LONG).show();
        }

    }
   /* public void LogInV2(View view) {
        String n = mail.getText().toString();
        Log.d("", n);
        String c = password.getText().toString();
        Log.d("", c);
        String url = "http://34.151.197.253:5000/userLogin";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JSONObject obj = new JSONObject();
        try {
            obj.put("emailEstudiante", n);
            obj.put("passwordEstudiante", c);
        } catch (JSONException e) {

        }
        StringRequest stringRequest = new StringRequest(Request.Method)
        requestQueue.add(jsonObjectRequest);
    }*/

    public void LogInCreateAccount(View view)
    {
        Intent actividad = new Intent(this,CreateAccount.class);
        startActivity(actividad);
    }
}