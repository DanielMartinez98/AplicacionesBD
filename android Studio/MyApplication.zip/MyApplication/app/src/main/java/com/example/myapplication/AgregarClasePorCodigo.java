package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class AgregarClasePorCodigo extends AppCompatActivity {
    SharedPreferences shrd;
    public static final String misPreferencias = "MisPref";
    public static final String Mail = "llavemail";
    public static final String Password = "llavepassword";
    public static final String ID = "llaveId";
    public EditText idclase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_clase_por_codigo);
        idclase = (EditText)findViewById(R.id.idClase);
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
    }
    public void AgregarClaseAgregarClasePorCodigo(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",shrd.getString(ID,""));
            obj.put("in_idClase",idclase.getText().toString());
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/crearClaseEstudiante",obj, response ->
        {
            finish();
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
    }
    public void AdministrarClaseAgregarClasePorCodigo(View view)
    {
        //Intent actividad = new Intent(this, AdministracionDeClases.class);
        //startActivity(actividad);
        finish();
    }
}