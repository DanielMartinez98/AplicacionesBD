package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME ="tareas.db";
    public static final String TABLE_NAME = "TareasList";
    public static final String TABLE_NAME2 = "ClasesList";
    public static final String COL = "nombreclase";
    public static final String COL1 = "descripcion";
    public static final String COL2 = "estatus";
    public static final String COL3 = "fecha";
    public static final String COL4 = "idclase";
    public static final String COL5 = "idtarea";
    public static final String COL6 = "nombre";
    public static final String COL7 = "administador";

    public DataBaseHelper(Context context)
    {
        super(context, DATABASE_NAME,null,3);
    }

    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_NAME +"("+COL5+" TEXT PRIMARY KEY,"+COL1+" TEXT,"+COL2 +" TEXT,"+COL3+" TEXT,"+COL4+" TEXT,"+COL+" TEXT,"+COL6+" TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE "+TABLE_NAME2 +"("+COL4+" TEXT PRIMARY KEY,"+COL+" TEXT,"+COL7+" TEXT)");
    }
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i ,int i1)
    {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME2);
    }
    //Metodo para Insertar Datos
    public boolean insertDataTareas(String a,String a1,String a2,String a3,String a4,String a5,String a6)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL,a);
        contentValues.put(COL1,a1);
        contentValues.put(COL2,a2);
        contentValues.put(COL3,a3);
        contentValues.put(COL4,a4);
        contentValues.put(COL5,a5);
        contentValues.put(COL6,a6);
        long result = database.insert(TABLE_NAME,null, contentValues);
        System.out.println("Insert "+result);
        if(result==-1)
            return  false;
        else
            return true;
    }
    public boolean insertDataClases(String a,String a1,String a2)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL4,a1);
        contentValues.put(COL7,a);
        contentValues.put(COL,a2);
        long result = database.insert(TABLE_NAME2,null, contentValues);
        System.out.println("Insert "+result);
        if(result==-1)
            return  false;
        else
            return true;
    }
    public Cursor retrieveDataTareas()
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM "+TABLE_NAME,null);
        return cursor;
    }
    public Cursor retrieveDataClases()
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM "+TABLE_NAME2,null);
        return cursor;
    }
    public Cursor retrieveDataTareaspec(String id)
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE "+COL5+"="+id,null);
        return cursor;
    }

    public Cursor getAdmin(String id)
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT "+COL7+" FROM "+TABLE_NAME2+" WHERE "+COL4+"="+id,null);
        return cursor;
    }
    public Cursor getAdminClase()
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT "+COL4+","+COL7+","+COL+" FROM "+TABLE_NAME2,null);
        return cursor;
    }
    public Cursor getdataClase(String id)
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT "+COL7+","+COL+" FROM "+TABLE_NAME2+" WHERE "+COL4+"="+id,null);
        return cursor;
    }
    public void UpdateTarea(String id,String nombre,String fecha,String desc, String status)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL5,id);
        contentValues.put(COL6,nombre);
        contentValues.put(COL3,fecha);
        contentValues.put(COL1,desc);
        contentValues.put(COL2,status);
        SQLiteDatabase database = this.getWritableDatabase();
        database.update(TABLE_NAME,contentValues,COL5+" = ?",new String[] {id});
    }
    public void DeleteTarea(String id)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABLE_NAME,COL5+" = ?",new String[] {id});
    }
    public Cursor Events()
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT "+COL3+" FROM "+TABLE_NAME,null);
        return cursor;
    }
    public void deleteClase(String id)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABLE_NAME2,COL4+" = ?",new String[] {id});
    }
    /*public Integer deleteData(String eID)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete(TABLE_NAME,,)
    }*/


}

