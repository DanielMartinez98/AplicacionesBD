package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AgregarClase extends AppCompatActivity {
    DataBaseHelper DB;
    List<listWhatsapp> elements;
    List<String> arr;
    public EditText name,whatsapp;
    SharedPreferences shrd;
    public static final String misPreferencias = "MisPref";
    public static final String Mail = "llavemail";
    public static final String Password = "llavepassword";
    public static final String ID = "llaveId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_clase);
        name = (EditText)findViewById(R.id.editClassName);
        whatsapp=(EditText)findViewById(R.id.editWhatsappNumber);
        elements = new ArrayList<>();
        arr = new ArrayList<>();
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        initLista();
    }
    public void AgregarClaseAgregarClase(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        for(int i =0;i<elements.size();i++)
        {
            arr.add(elements.get(i).number);
        }
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",shrd.getString(ID,""));
            obj.put("nombreClase",name.getText().toString());
            obj.put("telefonos",arr);
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/crearClase",obj, response ->
        {
            try {
                DB.insertDataClases(response.getString("newClassID").toString(),"3",name.getText().toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);

        finish();
    }
    public void AdministrarClaseAgregarClase(View view)
    {
        //Intent actividad = new Intent(this, AdministracionDeClases.class);
        //startActivity(actividad);
        finish();
    }
    public void initLista()
    {
        listAdapterWhatsapp listWhatsapp = new listAdapterWhatsapp(elements,this);
        RecyclerView recyclerView = findViewById(R.id.listaWhatsappView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listWhatsapp);
    }
    public void addElement(View view)
    {
        elements.add(new listWhatsapp(whatsapp.getText().toString(),"1",false,"0"));
        whatsapp.setText("");
        Log.d("",""+elements.size());
        initLista();
    }
}