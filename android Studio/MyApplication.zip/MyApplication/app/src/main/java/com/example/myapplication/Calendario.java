package com.example.myapplication;

import static androidx.constraintlayout.motion.utils.Oscillator.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.github.sundeepk.compactcalendarview.CompactCalendarView;
import com.github.sundeepk.compactcalendarview.domain.Event;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Calendario extends AppCompatActivity {

    CompactCalendarView compactCalendar;
    List<listaTarea> elements;
    DataBaseHelper DB;
    public TextView month;
    public Date lastDate;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM- yyyy", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);
        DB =new DataBaseHelper(this);
        final CompactCalendarView compactCalendarView = (CompactCalendarView) findViewById(R.id.calendar);
        month = (TextView) findViewById(R.id.Month);
        //getActionBar().setDisplayHomeAsUpEnabled(false);
        // Set first day of week to Monday, defaults to Monday so calling setFirstDayOfWeek is not necessary
        // Use constants provided by Java Calendar class
        compactCalendarView.setFirstDayOfWeek(Calendar.MONDAY);
        compactCalendar= (CompactCalendarView)findViewById(R.id.calendar);
        compactCalendar.setUseThreeLetterAbbreviation(true);
        month.setText(dateFormat.format(compactCalendar.getFirstDayOfCurrentMonth())+"");
        // Add event 1 on Sun, 07 Jun 2015 18:20:51 GMT
        Event ev1 = new Event(Color.GREEN, 1668317491000L, "");
        Cursor cursor = DB.Events();
        while (cursor.moveToNext())
        {
            Date date = stringToDate(cursor.getString(0));
            Log.d("",cursor.getString(0));
            long secondsSinceUnixEpoch = (date.getTime());
            Event e = new Event(Color.GREEN, secondsSinceUnixEpoch);
            compactCalendar.addEvent(e);
        }
        // Added event 2 GMT: Sun, 07 Jun 2015 19:10:51 GMT
        // Time is not relevant when querying for events, since events are returned by day.
        // So you can pass in any arbitary DateTime and you will receive all events for that day.
        List<Event> events = compactCalendar.getEvents(1668317491000L); // can also take a Date object
        // events has size 2 with the 2 events inserted previously
        Log.d(TAG, "Events: " + events);
        // define a listener to receive callbacks when certain events happen.
        compactCalendarView.setListener(new CompactCalendarView.CompactCalendarViewListener() {
            @Override
            public void onDayClick(Date dateClicked) {
                List<Event> events = compactCalendarView.getEvents(dateClicked);
                Log.d(TAG, "Day was clicked: " + dateClicked + " with events " + events);
                initLista(dateClicked);
            }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
                Log.d(TAG, "Month was scrolled to: " + firstDayOfNewMonth);
                month.setText(dateFormat.format(firstDayOfNewMonth)+"");
            }
        });
        initLista(Calendar.getInstance().getTime());
    }

    private Date stringToDate(String aDate) {
        if(aDate==null) return null;
        ParsePosition pos = new ParsePosition(0);
        SimpleDateFormat simpledateformat = new SimpleDateFormat("dd/MM/yyyy");
        Date stringDate = simpledateformat.parse(aDate, pos);
        return stringDate;
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        initLista(lastDate);

    }

    public void MainScreenCalendario(View view)
    {
        Intent actividad = new Intent(this, MainScreen.class);
        startActivity(actividad);
    }
    public void initLista(Date dateClicked)
    {
        lastDate = dateClicked;
        Cursor cursor = DB.retrieveDataTareas();
        elements = new ArrayList<>();
        while(cursor.moveToNext())
        {
            String dateStr = cursor.getString(3);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date;
            String dat ="0";
            String color;
            long diff1=0;
            try {
                Log.d("",dateStr);
                date = sdf.parse(dateStr);
                diff1 = date.getTime() - dateClicked.getTime();
                long diff = date.getTime() - Calendar.getInstance().getTime().getTime();
                dat = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)+"";
                Log.d("",dat);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String dat1 = TimeUnit.DAYS.convert(diff1, TimeUnit.MILLISECONDS)+"";
            Log.d("",dat1);
            if(cursor.getString(2).equals("1"))
            {
                color = "#0F9D58";
            }
            else if(Integer.parseInt(dat)<3)
            {
                color = "#FF0000";
            }
            else if(Integer.parseInt(dat)<5)
            {
                color = "#FFFFE0";
            }
            else
            {
                color = "#FFFFFF";
            }
            if(dat1.equals("0"))
            {
                Log.d("","in");
                elements.add(new listaTarea( cursor.getString(6),dat,cursor.getString(5),cursor.getString(0), Color.parseColor(color)));
            }
        }
        listAdapterTarea listTarea = new listAdapterTarea(elements,this);
        RecyclerView recyclerView = findViewById(R.id.RecyclerViewCalendario);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listTarea);
    }

}