package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class CreateAccount extends AppCompatActivity {

    EditText n,m,t,p1,p2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        n =(EditText) findViewById(R.id.name);
        m=(EditText) findViewById(R.id.mail);
        t=(EditText) findViewById(R.id.telefono);
        p1=(EditText) findViewById(R.id.password);
        p2=(EditText) findViewById(R.id.password2);

    }
    public void LogInCrearCuenta(View view)
    {
        finish();
    }
    public void CrearCuentaCrearCuenta(View view)
    {
        if(p1.getText().toString().equals(p2.getText().toString()))
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("nombre",n.getText().toString());
                obj.put("apellidoPaterno","");
                obj.put("apellidoMaterno","");
                obj.put("mail",m.getText().toString());
                obj.put("telefono",t.getText().toString());
                obj.put("password",p1.getText().toString());
                obj.put("whatsapp",0);
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/crearEstudiante",obj, response ->
            {
                finish();
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
        }
    }

}