package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AgregarTarea extends AppCompatActivity {

    public  EditText nombre,fecha,Descripcion;
    public Spinner clases;
    public Button agregarTarea;
    List<String> arr,arrid;
    DataBaseHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_tarea);
        DB =new DataBaseHelper(this);
        nombre=(EditText)findViewById(R.id.editNombreTarea);
        fecha=(EditText) findViewById(R.id.editTextDate);
        Descripcion =(EditText)findViewById(R.id.editTextDescripcion);
        agregarTarea=(Button)findViewById(R.id.AgregarTarea);
        clases =(Spinner)findViewById(R.id.spinner);
        Cursor cursor = DB.getAdminClase();
        arr = new ArrayList<String>();
        arrid = new ArrayList<String>();
        int count =0;
        while (cursor.moveToNext())
        {
            if(cursor.getString(1).equals("1"))
            {} else
            {
                arr.add(cursor.getString(2));
                arrid.add(cursor.getString(0));
                count++;
            }
        }
        if(count>0)
        {
            ArrayAdapter<String> adp = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arr);
            adp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            clases.setAdapter(adp);
        }else
        {
            agregarTarea.setEnabled(false);
        }
    }
    public void MainScreenAgregarTarea(View view)
    {
        finish();
    }
    public void AgregarTareaAgregarTarea(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("nombreTarea",nombre.getText().toString());
            obj.put("fecha",fecha.getText().toString());
            obj.put("descripcion",Descripcion.getText().toString());
            obj.put("idClase",arrid.get(arr.indexOf(clases.getSelectedItem().toString())));
        }catch (JSONException e)
        {
            Log.d("",e.toString());
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/agregarTarea",obj, response ->
        {
            finish();
        },error -> {
            Log.d("",error.toString());
        });
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
    }
    public void AgregarClaseAgregarTarea(View view)
    {
        Intent actividad = new Intent(this, AdministracionDeClases.class);
        startActivity(actividad);
    }
}