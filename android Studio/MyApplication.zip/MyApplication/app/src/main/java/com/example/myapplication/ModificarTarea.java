package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ModificarTarea extends AppCompatActivity {

    DataBaseHelper DB;
    public String id,idClase,idEst;
    public EditText nombre,date,descripcion;
    public CheckBox estatus;
    public boolean canChange;
    public Button delete;
    public static final String misPreferencias = "MisPref";
    public static final String ID = "llaveId";
    public SharedPreferences shrd;
    public int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_tarea);
        estatus=(CheckBox)findViewById(R.id.checkBox);
        descripcion=(EditText)findViewById(R.id.editTextDescripcion);
        date=(EditText)findViewById(R.id.editTextDate);
        nombre = (EditText)findViewById(R.id.editNombreTarea);
        delete =(Button)findViewById(R.id.AgregarTarea);
        DB =new DataBaseHelper(this);
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        if(shrd.contains(ID))
        {
            idEst = (shrd.getString(ID,""));
        }
        Intent mIntent = getIntent();
        id = mIntent.getStringExtra("StringVariableName");
        Log.d("",id+"");
        Cursor cursor = DB.retrieveDataTareaspec(id);

        if(cursor.getCount()>0)
        {
            cursor.moveToNext();
            Log.d("",id+" adentro");
            descripcion.setText(cursor.getString(1));
            date.setText(cursor.getString(3));
            nombre.setText(cursor.getString(5));
            idClase = cursor.getString(4);
            if(cursor.getString(2).equals("1"))
            {
                estatus.setChecked(true);
            }

        }
        Cursor cursor1 = DB.getAdmin(idClase);
        while(cursor1.moveToNext())
        {
            String a = cursor1.getString(0);
            if (a.equals("1"))
            {
                canChange = false;
                descripcion.setEnabled(false);
                date.setEnabled(false);
                nombre.setEnabled(false);
                delete.setEnabled(false);
            }else
            {
                canChange = true;
            }
        }
    }
    public void returnMain(View view)
    {
        //Intent actividad = new Intent(this,MainScreen.class);
        //startActivity(actividad);
        finish();
    }
    public void publishChanger(View view)
    {
        if(canChange)
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("idTarea",id);
                obj.put("nombre",nombre.getText().toString());
                obj.put("fecha",date.getText().toString());
                obj.put("descripcion",descripcion.getText().toString());
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarTarea",obj, response ->
            {
                count++;
                amount();
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
        }else
        {
            count++;
            amount();
        }
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",idEst);
            obj.put("idTarea",id);
            if(estatus.isChecked())
            {
                obj.put("isComplete",1);
            }else
            {
                obj.put("isComplete",0);
            }

        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarStatusTarea",obj, response ->
        {
            count++;
            amount();
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
    }
    public void amount()
    {
        String a ="";
        if(count>1)
        {
            if(estatus.isChecked())
            {
                a="1";
            }else
            {
                a="0";
            }
            DB.UpdateTarea(id,nombre.getText().toString(),date.getText().toString(),descripcion.getText().toString(),a);
            finish();
        }
    }
    public void Delete(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        DB.DeleteTarea(id);
        JSONObject obj = new JSONObject();
        try {
            obj.put("idEstudiante",idEst);
            obj.put("idTarea",id);
            if(estatus.isChecked())
            {
                obj.put("isComplete",1);
            }else
            {
                obj.put("isComplete",0);
            }

        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/borrarTarea",obj, response ->
        {
            finish();
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
    }
}