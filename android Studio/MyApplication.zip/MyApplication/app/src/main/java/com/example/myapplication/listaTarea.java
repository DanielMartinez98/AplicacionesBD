package com.example.myapplication;

import android.view.View;

import androidx.cardview.widget.CardView;

public class listaTarea {
    public int color;
    public String nombre;
    public String date;
    public String clase;
    public String id;
    public listaTarea(String nombre, String date, String clase,String id,int color) {
        this.nombre = nombre;
        this.date = date;
        this.clase = clase;
        this.id = id;
        this.color= color;
    }
    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }
}
