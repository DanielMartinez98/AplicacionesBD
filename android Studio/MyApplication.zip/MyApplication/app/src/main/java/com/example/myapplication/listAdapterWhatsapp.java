package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class listAdapterWhatsapp extends RecyclerView.Adapter<listAdapterWhatsapp.ViewHolder>
{
    private List<listWhatsapp> mData;
    private LayoutInflater mInflater;
    private Context context;
    public View view;

    public listAdapterWhatsapp(List<listWhatsapp> mData, Context context) {
        this.mData = mData;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public int getItemCount(){return mData.size();}

    @Override
    public listAdapterWhatsapp.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = mInflater.inflate(R.layout.listwhatsapp,null);
        return new listAdapterWhatsapp.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final listAdapterWhatsapp.ViewHolder holder,final int position)
    {
        holder.bindData(mData.get(position));
        listWhatsapp val1 = mData.get(position);
        String val = val1.number;
        String clas = val1.classid;
        holder.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String REQUEST_TAG = "objeto.ArrayRequest";
                JSONObject obj = new JSONObject();
                try {
                    obj.put("idClase",clas);
                    obj.put("telefono",val);
                    obj.put("administrad`or",holder.spinner.getSelectedItem().toString());
                }catch (JSONException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/CambiarAdministradorEstudiante",obj, response ->
                {
                },error -> {});
                Singleton.getInstance(holder.itemView.getContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        holder.itemView.findViewById(R.id.deletebutton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(val1.check)
                {
                    String REQUEST_TAG = "objeto.ArrayRequest";
                    JSONObject obj = new JSONObject();
                    try {
                        obj.put("idClase",clas);
                        obj.put("telefono",val);
                    }catch (JSONException e)
                    {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarClaseBorrar",obj, response ->
                    {
                    },error -> {});
                    Singleton.getInstance(holder.itemView.getContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
                }
                mData.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
                notifyItemRangeChanged(holder.getAdapterPosition(), mData.size());
            }
        });
    }

    public  void setItems(List<listWhatsapp> items){mData=items;}

    public class ViewHolder extends  RecyclerView.ViewHolder
    {
        TextView number;
        Spinner spinner;
        ViewHolder(View itemView)
        {
            super(itemView);
            number = itemView.findViewById(R.id.number);
            spinner = itemView.findViewById(R.id.power);
        }
        void bindData(final listWhatsapp item)
        {
            number.setText(item.getNumber());
        }
    }
}
