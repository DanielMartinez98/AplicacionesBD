package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class listAdapterClase extends RecyclerView.Adapter<listAdapterClase.ViewHolder> {
    private List<listaClase> mData;
    private LayoutInflater mInflater;
    private Context context;
    public View view;

    public listAdapterClase(List<listaClase> mData, Context context) {
        this.mData = mData;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public listAdapterClase.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.listclases, null);
        return new listAdapterClase.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final listAdapterClase.ViewHolder holder, final int position) {
        holder.bindData(mData.get(position));
        listaClase val1 = mData.get(position);
        String val = val1.id;
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {
                Intent actividad = new Intent(context, ModificarClase.class);
                actividad.putExtra("StringId", val);
                context.startActivity(actividad);
            }
        });
    }

    public void setItems(List<listaClase> items) {
        mData = items;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nombre;

        ViewHolder(View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.nombreTarea);

        }

        void bindData(final listaClase item) {
            nombre.setText(item.getNombre());
        }
    }
}