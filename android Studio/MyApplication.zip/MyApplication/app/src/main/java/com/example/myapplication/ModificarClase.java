package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ModificarClase extends AppCompatActivity {

    List<listWhatsapp> elements;
    public EditText name,whatsapp;
    public String id;
    DataBaseHelper DB;
    public TextView codigo;
    public Button add,mod;
    public boolean canEdit=false;
    SharedPreferences shrd;
    public static final String misPreferencias = "MisPref";
    public static final String ID = "llaveId";
    public static final String TEL="telefono";
    public String telefono = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar_clase);
        DB =new DataBaseHelper(this);
        name = (EditText) findViewById(R.id.editClassName);
        name.setEnabled(false);
        whatsapp = (EditText) findViewById(R.id.editWhatsappNumber);
        add = (Button)findViewById(R.id.addmod);
        mod = (Button)findViewById(R.id.modClasemod);
        codigo =(TextView)findViewById(R.id.Codigo);
        elements = new ArrayList<>();
        Intent mIntent = getIntent();
        id = mIntent.getStringExtra("StringId");
        codigo.setText(id);
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
        Cursor cursor = DB.getdataClase(id);
        while(cursor.moveToNext())
        {
            name.setText(cursor.getString(1));
            Log.d("",cursor.getString(0));
            if(cursor.getString(0).equals("3"))
            {
                canEdit=true;
            }
            else
            {
                name.setEnabled(false);
                whatsapp.setEnabled(false);
                add.setEnabled(false);
                mod.setEnabled(false);
            }
        }
        if(canEdit)
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("idClase",id);
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            MyJsonArrayRequest myJsonObjectRequest = new MyJsonArrayRequest(Request.Method.POST,"http://34.151.197.253:5000/telefonos",obj, response ->
            {
                for(int i = 0;i<response.length();i++)
                {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        elements.add(new listWhatsapp( jsonObject.getString("telefono"),"1",true,id));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
            initLista();
        }else
        {
            if(shrd.contains(TEL))
            {
                telefono = (shrd.getString(TEL,""));
            }

        }
    }
    public void returnMain(View view)
    {
        //Intent actividad = new Intent(this,MainScreen.class);
        //startActivity(actividad);
        finish();
    }
    public void initLista()
    {
        listAdapterWhatsapp listWhatsapp = new listAdapterWhatsapp(elements,this);
        RecyclerView recyclerView = findViewById(R.id.whatsappEditView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listWhatsapp);
    }
    public void addElementUserOnly(String a)
    {
        elements.add(new listWhatsapp(a,"1",true,id));
        initLista();
    }
    public void addElement(View view)
    {
        String REQUEST_TAG = "objeto.ArrayRequest";
        JSONObject obj = new JSONObject();
        try {
            obj.put("idClase",id);
            obj.put("telefono",telefono);
        }catch (JSONException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarClaseAgregar",obj, response ->
        {
        },error -> {});
        Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
        elements.add(new listWhatsapp(whatsapp.getText().toString(),"1",true,id));
        whatsapp.setText("");
        Log.d("",""+elements.size());
        initLista();
    }
    public void BorrarClase(View view)
    {
        if(canEdit)
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("idClase",id);
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/borrarClase",obj, response ->
            {
                DB.deleteClase(id);
                finish();
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);

        }else
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("idClase",id);
                obj.put("telefono",telefono);
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/modificarClaseBorrar",obj, response ->
            {
                DB.deleteClase(id);
                finish();
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);
        }
    }
}