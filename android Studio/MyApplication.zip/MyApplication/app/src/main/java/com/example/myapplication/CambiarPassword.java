package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class CambiarPassword extends AppCompatActivity {
    public EditText vieja,n1,n2;
    SharedPreferences shrd;
    public static final String misPreferencias = "MisPref";
    public static final String Mail = "llavemail";
    public static final String Password = "llavepassword";
    public static final String ID = "llaveId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambiar_password);
        shrd = getSharedPreferences(misPreferencias, Context.MODE_PRIVATE);
    }
    public void CambiarPasswordCambiarPassword(View view)
    {
        if(n1.getText().toString().equals(n2.getText().toString()))
        {
            String REQUEST_TAG = "objeto.ArrayRequest";
            JSONObject obj = new JSONObject();
            try {
                obj.put("idEstudiante",shrd.getString(ID,""));
                obj.put("passwordVieja",vieja.getText().toString());
                obj.put("passwordNueva",n1.getText().toString());
            }catch (JSONException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            JsonObjectRequest myJsonObjectRequest = new JsonObjectRequest(Request.Method.POST,"http://34.151.197.253:5000/cambiarPassword",obj, response ->
            {
                finish();
            },error -> {});
            Singleton.getInstance(getApplicationContext()).addRequestQueue(myJsonObjectRequest,REQUEST_TAG);

        }
        finish();
    }
    public void SettingsCambiarPassword(View view)
    {
        finish();
    }
}